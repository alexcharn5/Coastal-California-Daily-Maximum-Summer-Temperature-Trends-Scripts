library(ggplot2)
library(RColorBrewer)
library(gridExtra)

obj3_str  = c('','_3obj')[1]
nvars_str = c('','_2vars','_2vars_2')[1]
flag      = c('max','mean')[1]
load('div_rcp85_trends32.RData')
if (flag == 'max') div_trend_mat = div_max_trend_mat*100 else
div_trend_mat = div_mean_trend_mat*100

start_year   = 1950; end_year = 1985
year_list    = start_year:end_year; n_years    = length(year_list)
dataset_inds = c(1,2,4,6,8,10)    ; n_datasets = length(dataset_inds)

suffix   = c('','_var3')[1]
variable = c('trend','spacetime')[2]

datasets = c('BEST','nclimdiv','livneh_v1_1','livneh_v1_2','AgCFSR','CFSR','AgMERRA','MERRA','MERRA2','ERA5','NOAA_20CRv3','ERA_20C','JRA_55C')[dataset_inds]
titles   = c('BEST','nClimGrid','LIVNEH v1.1','Livneh','AgCFSR','CFSR','AgMERRA','MERRA','MERRA2','ERA5','NOAA 20CRv3','ERA 20C','JRA-55C')[dataset_inds]
col_list = brewer.pal(7,"Set1")[c(1,5,3,2,4,7)]

max_trend_master        = array(NA,dim=c(n_years,8,n_datasets,2))  ; mean_trend_master        = array(NA,dim=c(n_years,8,n_datasets,2))
rmse_perf_max           = array(NA,dim=c(n_years,n_datasets,2,2,2)); rmse_perf_mean           = array(NA,dim=c(n_years,n_datasets,2,2,2))
future_max_trend_master = array(NA,dim=c(n_years,8,n_datasets,3,2)); future_mean_trend_master = array(NA,dim=c(n_years,8,n_datasets,3,2))
trend_master = array(NA,dim=c(n_years,8,n_datasets,2)); rmse_perf = array(NA,dim=c(n_years,n_datasets,2,2,2)); future_trend_master = array(NA,dim=c(n_years,8,n_datasets,3,2))

if (variable == 'trend') load(paste0('gurobi_comp_trends_large',nvars_str,obj3_str,'_lots',suffix,'32.RData')) else
load(paste0('gurobi_comp_trends_large',nvars_str,obj3_str,'_lots_spacetime32.RData'))
#max_trend_master[,,,1]         = max_trend_ca_array; mean_trend_master[,,,1]         = mean_trend_ca_array
#rmse_perf_max[,,,,1]           = rmse_perf_max_mat ; rmse_perf_mean[,,,,1]           = rmse_perf_mean_mat
#future_max_trend_master[,,,,1] = future_max_trend  ; future_mean_trend_master[,,,,1] = future_mean_trend
mean_trend_master[,,,1] = get(paste0(flag,'_trend_ca_array')); rmse_perf_mean[,,,,1] = get(paste0('rmse_perf_',flag,'_mat')); future_mean_trend_master[,,,,1] = get(paste0('future_',flag,'_trend'))

if (variable == 'trend') load(paste0('gurobi_comp_trends_large',nvars_str,obj3_str,'_lots_rmse',suffix,'32.RData')) else
load(paste0('gurobi_comp_trends_large',nvars_str,obj3_str,'_lots_rmse_spacetime32.RData'))
#max_trend_master[,,,2]         = max_trend_ca_array; mean_trend_master[,,,2]         = mean_trend_ca_array
#rmse_perf_max[,,,,2]           = rmse_perf_max_mat ; rmse_perf_mean[,,,,2]           = rmse_perf_mean_mat
#future_max_trend_master[,,,,2] = future_max_trend  ; future_mean_trend_master[,,,,2] = future_mean_trend
mean_trend_master[,,,2] = get(paste0(flag,'_trend_ca_array')); rmse_perf_mean[,,,,2] = get(paste0('rmse_perf_',flag,'_mat')); future_mean_trend_master[,,,,2] = get(paste0('future_',flag,'_trend'))

max_trend_master        = max_trend_master*100       ; mean_trend_master        = mean_trend_master*100
future_max_trend_master = future_max_trend_master*100; future_mean_trend_master = future_mean_trend_master*100

inds_order = c(2,4,5,6,1,3)

test_df <- data.frame(
  Data = factor(rep(rep(titles, each = n_years), 2),
                levels = titles),
  Weighting = factor(rep(c("Weighting method: Perfect Model Test","Weighting method: Minimum Multimodel RMSE"), each = n_years*n_datasets),
                     levels = c("Weighting method: Perfect Model Test","Weighting method: Minimum Multimodel RMSE")),
  Year = rep(year_list,n_datasets*2),
  Difference = as.numeric(mean_trend_master[,8,,]) # rnorm(432)
)
test_df2 <- data.frame(
  Data = factor(rep(rep(titles, each = n_years), 4),
                levels = titles),
  Target = factor(rep(rep(c("In-sample (historical)","Out-of-sample (RCP 8.5)"), each = n_years*n_datasets), 2),
                  levels = c("In-sample (historical)","Out-of-sample (RCP 8.5)")),
  Weighting = factor(rep(c("Weighting method: Perfect Model Test","Weighting method: Minimum Multimodel RMSE"), each = 2*n_years*n_datasets),
                     levels = c("Weighting method: Perfect Model Test","Weighting method: Minimum Multimodel RMSE")),
  Year = rep(year_list, 2*n_datasets*2),
  RMSEimpr = as.numeric(rmse_perf_mean[,inds_order,,1,])  # rnorm(432*2)
)
test_df3 <- data.frame(
  Data = factor(rep(rep(c("BEST","Livneh"), each = n_years), 2),
                levels = titles),
  Weighting = factor(rep(c("Weighting method: Perfect Model Test","Weighting method: Minimum Multimodel RMSE"), each = n_years*2),
                     levels = c("Weighting method: Perfect Model Test","Weighting method: Minimum Multimodel RMSE")),
  Year = rep(year_list, 4),
  CAmean = as.numeric(future_mean_trend_master[,8,c(1,3),3,]) # rnorm(144)
)
test_df3$LB <- as.numeric(future_mean_trend_master[,8,c(1,3),2,]) # test_df3$CAmean - 1
test_df3$UB <- as.numeric(future_mean_trend_master[,8,c(1,3),1,]) # test_df3$CAmean + 1

pdf_title = paste0('comp_confidence_',variable,'_',flag,nvars_str,obj3_str,suffix,'32_mark.pdf')
pdf(pdf_title, height = 10, width = 11)
#pdf(pdf_title,width=10,height=12)
grid.arrange(
  ggplot(test_df, aes(x = Year, y = Difference, color = Data)) + 
    geom_hline(yintercept = 0, linetype = "dotted") + geom_line() + facet_grid(~ Weighting) +
    ggtitle("(a) Difference in California-Mean LOCA RCP 8.5 Trend from Unweighted Multimodel Mean (K/century)") + 
    scale_color_manual(values = col_list, name = "") + theme_bw() + 
    labs(y = "Difference (K/century)", x = "Historical Trend Start Year") +
    theme(legend.position = c(0.360,0.15), legend.direction = "horizontal",
          legend.background = element_rect(linetype="solid", color = "black")),
  ggplot(test_df2, aes(x = Year, y = RMSEimpr, color = Data, linetype = Target)) + 
    geom_hline(yintercept = 0, linetype = "dotted") + geom_line() + facet_grid(~ Weighting) +
    ggtitle("(b) RMSE Improvement (%)") + 
    scale_color_manual(values = col_list[inds_order], name = "") + 
    scale_linetype_manual(values = c(1,2), name = "") + theme_bw() + 
    labs(y = "RMSE Improvement (%)", x = "Historical Trend Start Year") +
    theme(legend.position = c(0.40,0.17), legend.direction = "vertical", legend.title = element_blank(),
          legend.background = element_rect(linetype="solid", color = "black")) +
    guides(color = "none"),
  ggplot(test_df3, aes(x = Year, y = CAmean)) + 
    geom_hline(yintercept = quantile(div_trend_mat[,8],c(0.17,0.83)), linetype = "dashed") + 
    geom_ribbon(aes(ymin = LB, ymax = UB, fill = Data), alpha = 0.2) +
    geom_line(aes(color = Data)) + facet_grid(~ Weighting) +
    ggtitle("(c) California-Mean LOCA RCP 8.5 Trend (K/century)") + 
    scale_color_manual(values = col_list[c(1,3)], name = "") +  
    scale_fill_manual(values = col_list[c(1,3)], name = "") + theme_bw() + 
    labs(y = "Trend (K/century)", x = "Historical Trend Start Year") +
    theme(legend.position = c(0.415,0.9), legend.direction = "horizontal",
          legend.background = element_rect(linetype="solid", color = "black")) +
    guides(fill = "none")
)
dev.off()
