liblocs = c('/usr/local/lib/R/site-library','/usr/lib/R/site-library','/usr/lib/R/library')
library(rmpk)
library(ROI); print(ROI_registered_solvers())
library(ROIoptimizer)
library(maps,lib.loc=liblocs)
library(akima,lib.loc=liblocs)
library(abind,lib.loc=liblocs)
library(plotrix,lib.loc=liblocs)
source('~/box_of_helper_functions.R')
#load('../../BEST/BEST_1950_2005.RData')
load('/opt/obrienta_startup/datasets/BEST/BEST_1950_2005.RData')
lon_best   = lon; lat_best = lat
lonlat_mat = as.matrix(expand.grid(lon_best,lat_best))
geog_best  = matrix(map.where('state',lonlat_mat[,1],lonlat_mat[,2]),length(lon_best),length(lat_best))
in_ca_best = which(geog_best=='california',arr.ind=T)

args         = (commandArgs(TRUE))
start_year   = as.numeric(args[1]); cat('start_year:',start_year,fill=T)
dataset_inds = as.numeric(args[2]); cat('dataset_inds:',dataset_inds,fill=T)

modelNames = c("ACCESS1-0", "ACCESS1-3", "CCSM4", "CESM1-BGC",
                "CESM1-CAM5", "CMCC-CM", "CMCC-CMS", "CNRM-CM5",
                "CSIRO-Mk3-6-0", "CanESM2", "EC-EARTH", "FGOALS-g2",
                "GFDL-CM3", "GFDL-ESM2G", "GFDL-ESM2M",
                "HadGEM2-AO", "IPSL-CM5A-LR", "IPSL-CM5A-MR",
                "MIROC-ESM", "MIROC-ESM-CHEM", "MIROC5", "MPI-ESM-LR",
                "MPI-ESM-MR", "MRI-CGCM3", "NorESM1-M",
                "bcc-csm1-1", "bcc-csm1-1-m", "inmcm4",
		"GISS-E2-H", "GISS-E2-R", "HadGEM2-CC", "HadGEM2-ES")
n_models = length(modelNames)

#future_max_trend_array = matrix(NA,n_models,dim(in_ca_best)[1]); future_mean_trend_array = matrix(NA,n_models,dim(in_ca_best)[1])
#ptm = proc.time()
#for (i in 1:n_models) {
#    load(paste0('../../LOCA_rcp85/',modelNames[i],'/',modelNames[i],'_2006_2099.RData')); trend_max[which(trend_max==-1e99)] = NA
#    if (i == 1) {
#       lonlat_mat = as.matrix(expand.grid(lon,lat))
#       geog       = matrix(map.where('state',lonlat_mat),length(lon),length(lat))
#    }
#    in_ca_finite                = which(geog=='california' & is.finite(trend_max),arr.ind=T)
#    future_max_trend_array[i,]  = interpp(lon[in_ca_finite[,1]],lat[in_ca_finite[,2]],trend_max[in_ca_finite],lon_best[in_ca_best[,1]],lat_best[in_ca_best[,2]])$z
#    in_ca_finite                = which(geog=='california' & is.finite(trend_mean),arr.ind=T)
#    future_mean_trend_array[i,] = interpp(lon[in_ca_finite[,1]],lat[in_ca_finite[,2]],trend_mean[in_ca_finite],lon_best[in_ca_best[,1]],lat_best[in_ca_best[,2]])$z
#}
#cat('time to interpolate RCP 8.5 trends:',proc.time()-ptm,fill=T)
load('/opt/obrienta_startup/datasets/LOCA/raw_data/interpolate_rcp85trends32.RData')
n_cells_future_max = dim(future_max_trend_array)[2]; n_cells_future_mean = dim(future_mean_trend_array)[2]

gurobi_optimize = function(obs_vec,model_mat,k,mu,sigma) {
		n = dim(model_mat)[1]
		solver <- ROI_optimizer("gurobi")
		model <- optimization_model(solver)
		x <- model$add_variable("x",type="binary",i=1:n)
		if (k == 1) {
		   model$set_objective(1/sigma[1]*(sum_expr(mean(model_mat[i,]^2)/k^2*x[i]^2
						+ -2*mean(obs_vec*model_mat[i,])/k*x[i]
						+ sum_expr(if (i<n) {2*mean(model_mat[i,]*model_mat[j,])/k^2*x[i]*x[j]} else 0,j=(i+1):n),i=1:n)+mean(obs_vec^2)-mu[1])
						+ 1/sigma[2]*(sum_expr(mean((model_mat[i,]-obs_vec)^2)/k*x[i],i=1:n)-mu[2])
						,sense="min")
		} else {
		   model$set_objective(1/sigma[1]*(sum_expr(mean(model_mat[i,]^2)/k^2*x[i]^2
						+ -2*mean(obs_vec*model_mat[i,])/k*x[i]
						+ sum_expr(if (i<n) {2*mean(model_mat[i,]*model_mat[j,])/k^2*x[i]*x[j]} else 0,j=(i+1):n),i=1:n)+mean(obs_vec^2)-mu[1])
						+ 1/sigma[2]*(sum_expr(get_rmse(model_mat[i,],obs_vec)^2/k*x[i],i=1:n)-mu[2])
						+ -1/sigma[3]*(2/(k*(k-1))*sum_expr(sum_expr(get_rmse(model_mat[i,],model_mat[j,])^2/mean(c(get_rmse(model_mat[i,],obs_vec)^2,get_rmse(model_mat[j,],obs_vec)^2))*x[i]*x[j],j=(i+1):n),i=1:(n-1))-mu[3])
						,sense="min")
		}
		model$add_constraint(sum_expr(x[i],i=1:n)==k)
		model$optimize()
		res  = model$get_variable_value(x[i]); res = as.matrix(res[,2:3]); res = res[order(res[,1]),]
		inds = which(abs(res[,2]-1)<0.01); if (length(inds) != k) stop('length(inds) != k')
return(inds)
}

dirs         = c('BEST','nclimdiv_gridded','LIVNEH','LIVNEH','AgCFSR','CFSR/hourly/max_hourly','AgMERRA','MERRA_hourlyT','MERRA2_tmax','ERA5','NOAA_20CRv3','ERA_20C','JRA_55C')
datasets     = c('BEST','nclimdiv','livneh_v1_1','livneh_v1_2','AgCFSR','CFSR','AgMERRA','MERRA','MERRA2','ERA5','NOAA_20CRv3','ERA_20C','JRA_55C')
starting_yrs = c(1950,1951,NA,1950,1980,1980,1980,1980,1980,1980,1950,1950,1980)

#dataset_inds = 1
end_year     = 2005
suffix_list  = c('','_var3')[1]
load_file    = 0
#for (start_year in 1950:1985) {
for (start_year in start_year) {
    for (suffix in suffix_list) {
    for (dataset_ind in dataset_inds) {
    if (starting_yrs[dataset_ind] <= start_year) {
    ptm = proc.time()
    cat('dataset:',datasets[dataset_ind],fill=T)
#    if (dataset_ind == 1) load(paste0('../../',dirs[dataset_ind],'/',datasets[dataset_ind],'_',start_year,'_',end_year,suffix,'.RData')) else
#    load(paste0('../../',dirs[dataset_ind],'/',datasets[dataset_ind],'_large_',start_year,'_',end_year,suffix,'.RData'))
    if (dataset_ind == 1) load(paste0('/opt/obrienta_startup/datasets/',dirs[dataset_ind],'/',datasets[dataset_ind],'_',start_year,'_',end_year,suffix,'.RData')) else
    load(paste0('/opt/obrienta_startup/datasets/',dirs[dataset_ind],'/',datasets[dataset_ind],'_large_',start_year,'_',end_year,suffix,'.RData'))
    trend_max[which(trend_max==-1e99)] = NA
    y_max = trend_max[in_ca_best]; y_mean = trend_mean[in_ca_best]
        
    filename = paste0('/opt/obrienta_startup/datasets/LOCA/raw_data/gurobi_large/gurobi_large32_3',datasets[dataset_ind],'_',start_year,'_',end_year,suffix,'.RData'); print(filename)
    if (load_file) {
       load(filename)
    } else {
       rmse_mat         = matrix(NA,n_models,2)
       model_list_max   = vector(mode='list',length=n_models)   ; indep_map_max     = NULL
       model_list_mean  = vector(mode='list',length=n_models)   ; indep_map_mean    = NULL
       inside_max_mat   = matrix(NA,n_models-1,2)               ; inside_mean_mat   = matrix(NA,n_models-1,2)
       rmse_perf_max    = array(NA,dim=c(n_models-1,2,n_models)); rmse_perf_mean    = array(NA,dim=c(n_models-1,2,n_models))
       rmse_perf_max_mm = array(NA,dim=c(n_models-1,2,n_models)); rmse_perf_mean_mm = array(NA,dim=c(n_models-1,2,n_models))
    }
    k1 = min(which(is.na(rmse_mat[,1]))); cat('first k:',k1,fill=T)

    max_trend_array       = matrix(NA,n_models,dim(in_ca_best)[1])
    max_trend_array_orig  = NULL
    mean_trend_array      = matrix(NA,n_models,dim(in_ca_best)[1])
    mean_trend_array_orig = NULL

    for (i in 1:n_models) {
	load(paste0('/opt/obrienta_startup/datasets/LOCA/raw_data/',modelNames[i],'/',modelNames[i],'_',start_year,'_',end_year,suffix,'_BEST.RData')); trend_max[which(trend_max==-1e99)] = NA
        max_trend_array_orig = abind(max_trend_array_orig,trend_max,along=3)
        max_trend_array[i,]  = trend_max[in_ca_best]

        mean_trend_array_orig = abind(mean_trend_array_orig,trend_mean,along=3)
        mean_trend_array[i,]  = trend_mean[in_ca_best]
    }
    finite_cells_max  = which(is.finite(y_max) & is.finite(apply(max_trend_array,2,mean)))  ; y_max  = y_max[finite_cells_max]  ; max_trend_array  = max_trend_array[,finite_cells_max]  ; n_cells_max  = length(finite_cells_max)
    finite_cells_mean = which(is.finite(y_mean) & is.finite(apply(mean_trend_array,2,mean))); y_mean = y_mean[finite_cells_mean]; mean_trend_array = mean_trend_array[,finite_cells_mean]; n_cells_mean = length(finite_cells_mean)
    cat(dim(in_ca_best)[1],'CA cells &',n_cells_max,'finite max cells &',n_cells_mean,'finite mean cells',fill=T)
    cat('time to interpolate models:',proc.time()-ptm,fill=T); ptm = proc.time()

    for (k in k1:(n_models-1)) {
        x1 = matrix(NA,100,2); x2 = matrix(NA,100,2); x3 = matrix(NA,100,2)
        ptm2 = proc.time()
        for (m in 1:100) {
            inds           = sample(n_models,k)
            trend_max_tmp  = matrix(max_trend_array[inds,],ncol=dim(max_trend_array)[2])  ; rmse_max  = apply(trend_max_tmp,1,function(x) get_rmse(x,y_max))
            trend_mean_tmp = matrix(mean_trend_array[inds,],ncol=dim(mean_trend_array)[2]); rmse_mean = apply(trend_mean_tmp,1,function(x) get_rmse(x,y_mean))
            A_tmp          = apply(trend_max_tmp,2,mean,na.rm=T) ; x1[m,1] = mean((A_tmp-y_max)^2)
            A_tmp          = sweep(trend_max_tmp,2,y_max,'-')^2  ; x2[m,1] = mean(apply(A_tmp,1,mean))
            A_tmp          = apply(trend_mean_tmp,2,mean,na.rm=T); x1[m,2] = mean((A_tmp-y_mean)^2)
            A_tmp          = sweep(trend_mean_tmp,2,y_mean,'-')^2; x2[m,2] = mean(apply(A_tmp,1,mean))
            if (k > 1) {
               sum_tmp_max = 0; sum_tmp_mean = 0
               for (i in 1:(length(inds)-1)) {
                   for (j in (i+1):length(inds)) {
                       sum_tmp_max  = sum_tmp_max + get_rmse(trend_max_tmp[i,],trend_max_tmp[j,])^2/mean(c(rmse_max[i]^2,rmse_max[j]^2))
                       sum_tmp_mean = sum_tmp_mean + get_rmse(trend_mean_tmp[i,],trend_mean_tmp[j,])^2/mean(c(rmse_mean[i]^2,rmse_mean[j]^2))
                   }
               }
               x3[m,1] = sum_tmp_max*2/(length(inds)*(length(inds)-1))
               x3[m,2] = sum_tmp_mean*2/(length(inds)*(length(inds)-1))
            }
        }
        mu1  = apply(x1,2,mean); sigma1 = apply(x1,2,sd)
        mu2  = apply(x2,2,mean); sigma2 = apply(x2,2,sd)
        if (k > 1) {
	   mu3 = apply(x3,2,mean); sigma3 = apply(x3,2,sd)
	   mu_max  = c(mu1[1],mu2[1],mu3[1]); sigma_max  = c(sigma1[1],sigma2[1],sigma3[1])
	   mu_mean = c(mu1[2],mu2[2],mu3[2]); sigma_mean = c(sigma1[2],sigma2[2],sigma3[2])
	} else {
	   mu_max  = c(mu1[1],mu2[1]); sigma_max  = c(sigma1[1],sigma2[1])
	   mu_mean = c(mu1[2],mu2[2]); sigma_mean = c(sigma1[2],sigma2[2])
	}
        cat('time to do 100 random samples:',proc.time()-ptm2,fill=T); ptm2 = proc.time()
	
    	inds                = gurobi_optimize(y_max,max_trend_array,k,mu_max,sigma_max)
	model_list_max[[k]] = inds                                                                      ; #rmse_mat[k,1] = model$objective_value()
	trend_max_tmp       = matrix(max_trend_array[model_list_max[[k]],],ncol=n_cells_max); rmse_mat[k,1] = get_rmse(y_max,apply(trend_max_tmp,2,mean))
	indep_map_max       = abind(indep_map_max,apply(max_trend_array_orig[,,model_list_max[[k]]],c(1,2),mean,na.rm=T),along=3)

	inds                 = gurobi_optimize(y_mean,mean_trend_array,k,mu_mean,sigma_mean)
	model_list_mean[[k]] = inds                                                                         ; #rmse_mat[k,2] = model$objective_value()
	trend_mean_tmp       = matrix(mean_trend_array[model_list_mean[[k]],],ncol=n_cells_mean); rmse_mat[k,2] = get_rmse(y_mean,apply(trend_mean_tmp,2,mean))
	indep_map_mean       = abind(indep_map_mean,apply(mean_trend_array_orig[,,model_list_mean[[k]]],c(1,2),mean,na.rm=T),along=3)

#	if (k >= 2) {
	   inside_max = 0; inside_mean = 0; inside_max_future = 0; inside_mean_future = 0
	   for (i in 1:n_models) {
	       max_trend_array_tmp  = max_trend_array[-i,]; future_max_trend_array_tmp = future_max_trend_array[-i,]
	       max_inds             = gurobi_optimize(max_trend_array[i,],max_trend_array_tmp,k,mu_max,sigma_max)
	       rmse_perf_max[k,1,i] = get_rmse(max_trend_array[i,],apply(matrix(max_trend_array_tmp[max_inds,],ncol=n_cells_max),2,mean))                     ; rmse_perf_max_mm[k,1,i] = get_rmse(max_trend_array[i,],apply(max_trend_array_tmp,2,mean))
	       rmse_perf_max[k,2,i] = get_rmse(future_max_trend_array[i,],apply(matrix(future_max_trend_array_tmp[max_inds,],ncol=n_cells_future_max),2,mean)); rmse_perf_max_mm[k,2,i] = get_rmse(future_max_trend_array[i,],apply(future_max_trend_array_tmp,2,mean))
	       for (j in 1:n_cells_max) {
	       	   max_percs = qnorm(c(0.1,0.9),mean(max_trend_array_tmp[max_inds,j]),max(0,sd(max_trend_array_tmp[max_inds,j]),na.rm=T))
		   if (max_trend_array[i,j] >= max_percs[1] & max_trend_array[i,j] <= max_percs[2]) inside_max = inside_max + 1
	       }
	       for (j in 1:n_cells_future_max) {
	       	   max_percs = qnorm(c(0.1,0.9),mean(future_max_trend_array_tmp[max_inds,j]),max(0,sd(future_max_trend_array_tmp[max_inds,j]),na.rm=T))
		   if (future_max_trend_array[i,j] >= max_percs[1] & future_max_trend_array[i,j] <= max_percs[2]) inside_max_future = inside_max_future + 1
	       }

	       mean_trend_array_tmp  = mean_trend_array[-i,]; future_mean_trend_array_tmp = future_mean_trend_array[-i,]
	       mean_inds             = gurobi_optimize(mean_trend_array[i,],mean_trend_array_tmp,k,mu_mean,sigma_mean)
               rmse_perf_mean[k,1,i] = get_rmse(mean_trend_array[i,],apply(matrix(mean_trend_array_tmp[mean_inds,],ncol=n_cells_mean),2,mean))                     ; rmse_perf_mean_mm[k,1,i] = get_rmse(mean_trend_array[i,],apply(mean_trend_array_tmp,2,mean))
               rmse_perf_mean[k,2,i] = get_rmse(future_mean_trend_array[i,],apply(matrix(future_mean_trend_array_tmp[mean_inds,],ncol=n_cells_future_mean),2,mean)); rmse_perf_mean_mm[k,2,i] = get_rmse(future_mean_trend_array[i,],apply(future_mean_trend_array_tmp,2,mean))
	       for (j in 1:n_cells_mean) {
	       	   mean_percs = qnorm(c(0.1,0.9),mean(mean_trend_array_tmp[mean_inds,j]),max(0,sd(mean_trend_array_tmp[mean_inds,j]),na.rm=T))
		   if (mean_trend_array[i,j] >= mean_percs[1] & mean_trend_array[i,j] <= mean_percs[2]) inside_mean = inside_mean + 1
	       }
	       for (j in 1:n_cells_future_mean) {
	       	   mean_percs = qnorm(c(0.1,0.9),mean(future_mean_trend_array_tmp[mean_inds,j]),max(0,sd(future_mean_trend_array_tmp[mean_inds,j]),na.rm=T))
		   if (future_mean_trend_array[i,j] >= mean_percs[1] & future_mean_trend_array[i,j] <= mean_percs[2]) inside_mean_future = inside_mean_future + 1
	       }
	   }
	   inside_max  = inside_max/(n_cells_max*n_models)  ; inside_max_future  = inside_max_future/(n_cells_future_max*n_models)  ; inside_max_mat[k,]  = c(inside_max,inside_max_future)  ; print(inside_max_mat[1:k,])
	   inside_mean = inside_mean/(n_cells_mean*n_models); inside_mean_future = inside_mean_future/(n_cells_future_mean*n_models); inside_mean_mat[k,] = c(inside_mean,inside_mean_future); print(inside_mean_mat[1:k,])
#	}
	#save(model_list_max,model_list_mean,rmse_mat,indep_map_max,indep_map_mean,inside_max_mat,inside_mean_mat,rmse_perf_max,rmse_perf_mean,rmse_perf_max_mm,rmse_perf_mean_mm,file=filename)
	cat('time to do k = ',k,'is',proc.time()-ptm2,fill=T)
    }
#    plot(inside_max_mat[,1],ylim=range(c(inside_max_mat,inside_mean_mat)),type='o'); points(inside_mean_mat[,1],type='o',lty=2); points(inside_max_mat[,2],type='o',col='blue'); points(inside_mean_mat[,2],type='o',col='blue',lty=2); abline(h=0.8,lty=3)
#    A_max = apply((rmse_perf_max_mm-rmse_perf_max)/rmse_perf_max_mm*100,c(1,2),mean); A_mean = apply((rmse_perf_mean_mm-rmse_perf_mean)/rmse_perf_mean_mm*100,c(1,2),mean)
#    dev.new(); plot(A_max[,1],ylim=range(c(A_max,A_mean)),type='o',xlab='Subset Size',ylab='RMSE Improvement (%)'); points(A_mean[,1],type='o',lty=2); points(A_max[,2],type='o',col='blue'); points(A_mean[,2],type='o',col='blue',lty=2); abline(h=0,lty=3)
    model_list_max[[n_models]]  = 1:n_models; indep_map_max  = abind(indep_map_max,apply(max_trend_array_orig,c(1,2),mean,na.rm=T),along=3)
    model_list_mean[[n_models]] = 1:n_models; indep_map_mean = abind(indep_map_mean,apply(mean_trend_array_orig,c(1,2),mean,na.rm=T),along=3)
    A_max  = apply(max_trend_array,2,mean,na.rm=T) ; rmse_mat[n_models,1] = get_rmse(y_max,A_max)
    A_mean = apply(mean_trend_array,2,mean,na.rm=T); rmse_mat[n_models,2] = get_rmse(y_mean,A_mean); #dev.new(); plot(rmse_mat[,1],type='o',ylim=range(rmse_mat)); points(rmse_mat[,2],col='blue',type='o')

    cat('time to do gurobi:',proc.time()-ptm,fill=T)
    save(model_list_max,model_list_mean,rmse_mat,indep_map_max,indep_map_mean,inside_max_mat,inside_mean_mat,rmse_perf_max,rmse_perf_mean,rmse_perf_max_mm,rmse_perf_mean_mm,file=filename)
}
}
}
}
