#library(fields)
#library(maps)
#library(geosphere)
#library(ggplot2)
#source('~/box_of_helper_functions.R')
#load('stations.RData')
#load('station_data.RData')
#load('../breakpt_adjusted/station_data.RData')
#in_ca = intersect(grep('CA',stations[,6]),grep('United States',stations[,5]))
#print('data loaded')
#
#lonlat_trendmat_list = list()
#plot_flag            = 0
#year_start_list = c(1950,1970)[2]; year_end_list = c(2005,2019)
##year_start_list = 1950:1985; year_end_list = 2005
#for (year_start in year_start_list) {
#for (year_end in year_end_list) {
#print(c(year_start,year_end))
#year_list       = year_start:year_end
#var_analysis    = 0
#length_inds     = NULL
#lonlat_trendmat = NULL
#if (var_analysis) {
#   load('/N/project/obrienta_startup/datasets/variability_modes/var_jja.RData'); var_jja = data.frame(var_jja); cat('Original dim(var_jja):',dim(var_jja),fill=T)
#   relevant_var_years = which(var_jja[,1]>=year_start & var_jja[,1]<=year_end)
#   var_jja            = var_jja[relevant_var_years,]; cat('New dim(var_jja):',dim(var_jja),fill=T)
#}
#
#percent = 0
#for (i in 1:length(in_ca)) {
#    if (i/length(in_ca)*100 >= percent) {cat(percent,'% (',i,'/',length(in_ca),') done',fill=T); percent = percent + 5}
#    inds = which(station_data[,1]==stations[in_ca[i],1]); inds_adj = which(station_data_adj[,1]==stations[in_ca[i],1]); if (!identical(inds,inds_adj)) stop('UMMM')
#    if (length(inds) > 0) {
#       recording_dates = station_data[inds,3]
#       temperatures    = station_data[inds,4]; temperatures_adj = station_data_adj[inds,4]
#       lon_station     = stations[in_ca[i],4]
#       lat_station     = stations[in_ca[i],3]
#       location        = map.where('state',lon_station,lat_station)
#       if (min(recording_dates)<=year_start & max(recording_dates)>=year_end & !(is.na(location)) & location=='california') {
#       	  years      = recording_dates%/%1
#	  months     = round(recording_dates%%1*12+0.5)
#	  timeseries = cbind(year_list,matrix(NA,length(year_list),2))
#	  for (j in 1:dim(timeseries)[1]) {
#	      year_inds = which(years==timeseries[j,1])
#	      if (length(year_inds) >= 2) {
#	      	 year_month_inds = year_inds[which(months[year_inds] %in% 6:8)]
#		 timeseries[j,2] = mean(temperatures[year_month_inds])
#		 timeseries[j,3] = mean(temperatures_adj[year_month_inds])
#	      }
#	  }
#	  finite_inds1   = which(is.finite(timeseries[,2])); finite_inds2 = which(is.finite(timeseries[,3]))
#	  finite_inds    = intersect(finite_inds1,finite_inds2); if (!identical(finite_inds1,finite_inds)) stop('hmm')
#	  relevant_years = timeseries[finite_inds,1]
#	  relevant_temps = timeseries[finite_inds,2]; relevant_temps_adj = timeseries[finite_inds,3]
#	  if (length(relevant_years) >= (length(year_list)-15)) {
#	     length_inds = c(length_inds,length(finite_inds))
#	     if (var_analysis) {
#	     	fit     = lm(relevant_temps~Year+ELI+PNA1+PDO,data=var_jja[finite_inds,])
#		fit_adj = lm(relevant_temps_adj~Year+ELI+PNA1+PDO,data=var_jja[finite_inds,])
#	     } else {
#	        fit     = lm(relevant_temps~relevant_years)
#		fit_adj = lm(relevant_temps_adj~relevant_years)
#	     }
#	     lonlat_trendmat = rbind(lonlat_trendmat,c(lon_station,lat_station,fit$coefficients[2],summary(fit)$coefficients[2,4],fit_adj$coefficients[2],summary(fit_adj)$coefficients[2,4]))
#	  }
#       }
#    }
#}
#lonlat_trendmat_list = append(lonlat_trendmat_list,list(lonlat_trendmat))
##save(lonlat_trendmat_list,file='station_trends_historical.RData')
#
#if (plot_flag) {
#titles   = c('All Points','p < 0.05','Multiple-Hypothesis Testing')
#x1       = 0.14
#xwidth   = (1-x1-0.04)/3
#xmargins = seq(x1,1,xwidth); xmargins = cbind(xmargins,xmargins+xwidth+0.04)
#xmargins = xmargins[1:3,]
##break_interval = 0.03; break_scale_max = break_interval*3.5
#break_interval = 0.02; break_scale_max = break_interval*5.5
#breaks_master  = seq(-(break_scale_max+break_interval),break_scale_max+break_interval,break_interval)
#cut_master     = breaks_master; cut_master[c(1,length(cut_master))] = c(-1,1)*Inf
#n_breaks       = length(breaks_master)
#col_list       = rev(pal(n_breaks-1))
#
#stn_plot = 0
#if (stn_plot) {
#   width     = 12; height = 8
#   xlimits   = c(-125,-114); xlabels = seq(-124,-114,3)
#   ylimits   = c(32,42)    ; ylabels = seq(32,42,2)
#   mtext_adj = c(1.2,1.4)
#   pch_cex   = 0.5
#} else {
#   width     = 16; height = 7
#   xlimits   = c(-118.7,-116.6); xlabels = seq(-118.5,-117,0.5)
#   ylimits   = c(33.5,34.4)    ; ylabels = seq(33.5,34.25,0.25)
#   mtext_adj = c(1.4,1.7)
#   pch_cex   = 0.8
#}
#pdf(paste0('station_trends_',year_start,'_',year_end,'.pdf'),width=width,height=height); mar_margins = c(2.9,1,1.3,2.1)
#legendlab = bquote(.(year_start)~'-'~.(year_end)~Trend~(K~yr^-1))
#for (i in 1:3) {
#    p_FDR    = get_p_FDR(lonlat_trendmat[,4])
#    sig_pts  = which(lonlat_trendmat[,4]<=c(1,0.05,p_FDR)[i])
#    d        = data.frame(lonlat_trendmat)[sig_pts,1:3]
#    fig_margins = c(xmargins[i,],0.52,0.97)
#    if (i == 1) par(fig=fig_margins,mar=mar_margins) else
#    par(fig=fig_margins,mar=mar_margins,new=T)
#    cols = col_list[as.numeric(cut(d[,3],breaks=cut_master))]
#    plot(d[,1],d[,2],pch=19,col=cols,xlim=xlimits,ylim=ylimits,xaxt='n',yaxt='n',xlab='',ylab='',cex=pch_cex); map('state',add=T)
#    if (i == 1) {
#       axis(side=2,at=ylabels,labels=ylabels,cex.axis=0.6,las=1)
#       mtext('Nonhomogenized',side=2,las=1,adj=mtext_adj[1],cex=1.1)
#    }
#    mtext(titles[i],side=3,line=0.7,cex=1.5)
#
#    p_FDR    = get_p_FDR(lonlat_trendmat[,6])
#    sig_pts  = which(lonlat_trendmat[,6]<=c(1,0.05,p_FDR)[i])
#    d        = data.frame(lonlat_trendmat)[sig_pts,c(1,2,5)]
#    fig_margins = c(xmargins[i,],0.14,0.59)
#    par(fig=fig_margins,mar=mar_margins,new=T)
#    cols = col_list[as.numeric(cut(d[,3],breaks=cut_master))]
#    plot(d[,1],d[,2],pch=19,col=cols,xlim=xlimits,ylim=ylimits,xaxt='n',yaxt='n',xlab='',ylab='',cex=pch_cex); map('state',add=T)
#    if (i == 1) {
#       axis(side=2,at=ylabels,labels=ylabels,cex.axis=0.6,las=1)
#       mtext('Homogenized',side=2,las=1,adj=mtext_adj[2],cex=1.1)
#    }
#    axis(side=1,at=xlabels,labels=xlabels,cex.axis=0.6,padj=-2)
#}
#par(fig=c(0,1,0,1),new=T)
#image.plot(legend.only=T,legend.args=list(text=legendlab,cex=1.3,side=1,line=3.3),legend.shrink=0.95,legend.mar=4.5,zlim=range(breaks_master),col=col_list,breaks=breaks_master,horizontal=T,axis.args=list(at=breaks_master[2:(n_breaks-1)],labels=breaks_master[2:(n_breaks-1)]))
#dev.off()
#}
#}
#}

titles   = c('1970-2005','1970-2019')
x1       = 0.16
xwidth   = (1-x1-0.04)/2
xmargins = seq(x1,1,xwidth); xmargins = cbind(xmargins,xmargins+xwidth+0.04); print(xmargins)
xmargins = xmargins[1:2,]; print(xmargins)
#ymargins = rbind(c(0.52,0.97),c(0.14,0.59))
ymargins = rbind(c(0.47,0.97),c(0.03,0.53))
break_interval = 0.2; break_scale_max = break_interval*5.5
break_labels   = seq(-break_scale_max,break_scale_max,break_interval)
breaks_master  = seq(-(break_scale_max+break_interval),break_scale_max+break_interval,break_interval)
cut_master     = breaks_master; cut_master[c(1,length(cut_master))] = c(-1,1)*Inf
cut_master     = c(-Inf,0,Inf)
n_breaks       = length(cut_master)
col_list       = rev(pal(n_breaks-1))
library(RColorBrewer)
col_list = rev(brewer.pal(7,"Set1")[c(1,5,3,2,4,7)][c(2,4)])

plot_region = c('ca','socab','sfba')[1]
if (plot_region == 'ca') {
   width     = 11; height = 9
#   xlimits   = c(-125,-114); xlabels = seq(-124,-115,3)
   xlimits   = c(-124.25,-114.5); xlabels = seq(-124,-115,3)
#   ylimits   = c(32,42)    ; ylabels = seq(32,42,2)
   ylimits   = c(32.25,41.75); ylabels = seq(32,42,2)
   mtext_adj = 1.4
   pch_cex   = 0.8
} else if (plot_region == 'socab') {
   width     = 12; height = 7
   xlimits   = c(-118.7,-116.6); xlabels = seq(-118.5,-117,0.5)
   ylimits   = c(33.5,34.4)    ; ylabels = seq(33.5,34.25,0.25)
   mtext_adj = 1.7
   pch_cex   = 1.2
} else if (plot_region == 'sfba') {
   width     = 11; height = 9
   xlimits   = c(-122.8,-120.7); xlabels = seq(-122.5,-121,0.5)
   ylimits   = c(37,38.55)     ; ylabels = seq(37,38.5,0.5)
   mtext_adj = 1.7
   pch_cex   = 1.2
}
pdf(paste0('station_trends_comp_',plot_region,'.pdf'),width=width,height=height); mar_margins = c(2.9,1,1.3,2.1)
legendlab = bquote(K~decade^-1)
for (i in 1:2) {
    lonlat_trendmat = lonlat_trendmat_list[[i]]
    p_FDR       = get_p_FDR(lonlat_trendmat[,4])
    nonsig_pts  = which(lonlat_trendmat[,4]>0.05)                             ; nonsig_pts_FDR = which(lonlat_trendmat[,4]>p_FDR)
    sig_pts     = which(lonlat_trendmat[,4]<=0.05 & lonlat_trendmat[,4]>p_FDR); sig_pts_FDR    = which(lonlat_trendmat[,4]<=p_FDR)
    d           = data.frame(lonlat_trendmat)[,1:3]
    fig_margins = c(xmargins[1,],ymargins[i,])
    if (i == 1) par(fig=fig_margins,mar=mar_margins) else
    par(fig=fig_margins,mar=mar_margins,new=T)
    cols = col_list[as.numeric(cut(d[,3]*10,breaks=cut_master))]
#    plot(d[,1],d[,2],pch=19,col=cols,xlim=xlimits,ylim=ylimits,xaxt='n',yaxt='n',xlab='',ylab='',cex=pch_cex); map('state',add=T)
#    points(d[nonsig_pts,1],d[nonsig_pts,2],pch=4,cex=pch_cex/2); points(d[nonsig_pts_FDR,1],d[nonsig_pts_FDR,2],pch=3,cex=pch_cex/2)
    plot(d[,1],d[,2],col=cols,xlim=xlimits,ylim=ylimits,xaxt='n',yaxt='n',xlab='',ylab='',cex=pch_cex); map('state',add=T)
    points(d[sig_pts,1],d[sig_pts,2],pch=3,cex=pch_cex*1.25,col=cols[sig_pts]); points(d[sig_pts_FDR,1],d[sig_pts_FDR,2],pch=19,cex=pch_cex,col=cols[sig_pts_FDR])
    if (i == 1) mtext('Nonhomogenized',side=3,line=0.7,cex=1.5)
    if (i == 2) axis(side=1,at=xlabels,labels=xlabels,cex.axis=1,padj=-0.5)
    axis(side=2,at=ylabels,labels=ylabels,cex.axis=1,las=1)
    mtext(titles[i],side=2,las=1,adj=mtext_adj,cex=1.5)

    p_FDR       = get_p_FDR(lonlat_trendmat[,6])
    nonsig_pts  = which(lonlat_trendmat[,6]>0.05)                             ; nonsig_pts_FDR = which(lonlat_trendmat[,6]>p_FDR)
    sig_pts     = which(lonlat_trendmat[,6]<=0.05 & lonlat_trendmat[,6]>p_FDR); sig_pts_FDR    = which(lonlat_trendmat[,6]<=p_FDR)
    d           = data.frame(lonlat_trendmat)[,c(1,2,5)]
    fig_margins = c(xmargins[2,],ymargins[i,])
    par(fig=fig_margins,mar=mar_margins,new=T)
    cols = col_list[as.numeric(cut(d[,3]*10,breaks=cut_master))]
#    plot(d[,1],d[,2],pch=19,col=cols,xlim=xlimits,ylim=ylimits,xaxt='n',yaxt='n',xlab='',ylab='',cex=pch_cex); map('state',add=T)
#    points(d[nonsig_pts,1],d[nonsig_pts,2],pch=4,cex=pch_cex/2); points(d[nonsig_pts_FDR,1],d[nonsig_pts_FDR,2],pch=3,cex=pch_cex/2)
    plot(d[,1],d[,2],col=cols,xlim=xlimits,ylim=ylimits,xaxt='n',yaxt='n',xlab='',ylab='',cex=pch_cex); map('state',add=T)
    points(d[sig_pts,1],d[sig_pts,2],pch=3,cex=pch_cex*0.85,col=cols[sig_pts]); points(d[sig_pts_FDR,1],d[sig_pts_FDR,2],pch=19,cex=pch_cex,col=cols[sig_pts_FDR])
    if (i == 1) mtext('Homogenized',side=3,line=0.7,cex=1.5)
    if (i == 2) axis(side=1,at=xlabels,labels=xlabels,cex.axis=1,padj=-0.5)
}
par(fig=c(0,1,0,1),new=T)
#image.plot(legend.only=T,legend.args=list(text=legendlab,cex=1.3,side=1,line=3.3),legend.shrink=0.95,legend.mar=4.5,zlim=range(breaks_master),col=col_list,breaks=breaks_master,horizontal=T,axis.args=list(at=break_labels,labels=break_labels,cex.axis=1))
dev.off()
stop()


MainStates = map_data('state')
zlimit     = c(-0.155,0.155)
for (i in 1:3) {
dev.new()
p_FDR    = get_p_FDR(lonlat_trendmat[,4])
sig_pts  = which(lonlat_trendmat[,4]<=c(1,0.05,p_FDR)[i])
d        = data.frame(lonlat_trendmat)[sig_pts,1:3]
names(d) = c('lon','lat','temp')
#zlimit   = max(abs(d$temp)); zlimit = c(-zlimit,zlimit)
sp = ggplot(data=MainStates,aes(x=long,y=lat,group=group),color='black') + geom_path() + geom_point(data=d,aes(x=lon,y=lat,color=temp,group=NULL)) + scale_color_gradient2(midpoint=0,low='blue',mid='white',high='red',limits=zlimit) + xlim(-125,-114) + ylim(32,43) + xlab('Longitude') + ylab('Latitude') + labs(color="Trend (K/yr)",title=paste0(year_start,'-',year_end,' Unadjusted Trend (',titles[i],')'))
print(sp)

dev.new()
p_FDR    = get_p_FDR(lonlat_trendmat[,6])
sig_pts  = which(lonlat_trendmat[,6]<=c(1,0.05,p_FDR)[i])
d        = data.frame(lonlat_trendmat)[sig_pts,c(1,2,5)]
names(d) = c('lon','lat','temp')
#zlimit   = max(abs(d$temp)); zlimit = c(-zlimit,zlimit)
sp = ggplot(data=MainStates,aes(x=long,y=lat,group=group),color='black') + geom_path() + geom_point(data=d,aes(x=lon,y=lat,color=temp,group=NULL)) + scale_color_gradient2(midpoint=0,low='blue',mid='white',high='red',limits=zlimit) + xlim(-125,-114) + ylim(32,43) + xlab('Longitude') + ylab('Latitude') + labs(color="Trend (K/yr)",title=paste0(year_start,'-',year_end,' Breakpoint-Adjusted Trend (',titles[i],')'))
print(sp)
}
