library(fields)
library(maps)
library(viridis)
source('~/box_of_helper_functions.R')
load('ACCESS1-0/ACCESS1-0_2006_2099.RData'); longitude = lon; latitude = lat
lonlat_mat = as.matrix(expand.grid(longitude,latitude))
geog       = matrix(map.where('state',lonlat_mat),length(longitude),length(latitude))
not_in_ca  = which(geog!='california' | is.na(geog),arr.ind=T)
flag       = c('max','mean')[1]
variable   = c('trend','spacetime')[2]
suffix     = c('','_var3')[1]

modelNames = c("ACCESS1-0", "ACCESS1-3", "CCSM4", "CESM1-BGC",
                "CESM1-CAM5", "CMCC-CM", "CMCC-CMS", "CNRM-CM5",
                "CSIRO-Mk3-6-0", "CanESM2", "EC-EARTH", "FGOALS-g2",
                "GFDL-CM3", "GFDL-ESM2G", "GFDL-ESM2M",
                "HadGEM2-AO", "IPSL-CM5A-LR", "IPSL-CM5A-MR",
                "MIROC-ESM", "MIROC-ESM-CHEM", "MIROC5", "MPI-ESM-LR",
                "MPI-ESM-MR", "MRI-CGCM3", "NorESM1-M",
                "bcc-csm1-1", "bcc-csm1-1-m", "inmcm4",
		"GISS-E2-H", "GISS-E2-R", "HadGEM2-CC", "HadGEM2-ES")
n_models = length(modelNames)

ptm = proc.time()
max_trend_array  = array(NA,dim=c(length(lon),length(lat),n_models))
mean_trend_array = array(NA,dim=c(length(lon),length(lat),n_models))
ptm = proc.time()
for (i in 1:n_models) {
    load(paste0(modelNames[i],'/',modelNames[i],'_2006_2099.RData')); trend_max[which(trend_max==-1e99)] = NA
    max_trend_array[,,i]  = trend_max
    mean_trend_array[,,i] = trend_mean
}
if (flag == 'max') mm_map = apply(max_trend_array,c(1,2),mean,na.rm=T) else
mm_map = apply(mean_trend_array,c(1,2),mean,na.rm=T)
mm_map[not_in_ca] = NA; mm_map = mm_map*100
cat('time to load RCP 8.5 models:',proc.time()-ptm,fill=T)

comp_mm_array = array(NA,dim=c(length(longitude),length(latitude),4))
if (variable == 'trend') load(paste0('gurobi_comp_trends_large_lots',suffix,'32.RData')) else
load('gurobi_comp_trends_large_lots_spacetime32.RData')
if (flag == 'max') comp_mm_array[,,1:2] = comp_mm_max[,,1,c(1,3)]*100 else
comp_mm_array[,,1:2] = comp_mm_mean[,,1,c(1,3)]*100

if (variable == 'trend') load(paste0('gurobi_comp_trends_large_lots_rmse',suffix,'32.RData')) else
load('gurobi_comp_trends_large_lots_rmse_spacetime32.RData')
if (flag == 'max') comp_mm_array[,,3:4] = comp_mm_max[,,1,c(1,3)]*100 else
comp_mm_array[,,3:4] = comp_mm_mean[,,1,c(1,3)]*100

legendlab = expression(K~century^-1)
pdftitle = paste0('five_maps_',variable,'_',flag,'32.pdf')
if (is.null(pdftitle)) dev.new(width=7.5,height=10) else
pdf(pdftitle,width=7.5,height=10)

xlimit = c(-125,-114); ylimit = c(32,42.5); zlimit = c(-1,1)*max(abs(comp_mm_array),na.rm=T)
fig_margins_master = c(0.225,0.775,0.68,1)
fig_margins        = matrix(NA,4,4)
fig_margins[1,]    = c(0.05,0.6,0.35,0.70); fig_margins[2,] = c(0.05,0.6,0.08,0.43); fig_margins[3,] = c(0.45,1,0.35,0.7); fig_margins[4,] = c(0.45,1,0.08,0.43)
mar_margins        = c(2.1,2,2.1,2.1)

par(fig=fig_margins_master,mar=c(1.9,2,1.3,2.1))
image(lon,lat,mm_map,axes=F,xlab='',ylab='',xlim=xlimit,ylim=ylimit,col=inferno(100)); #map('state',add=T)
mtext('LOCA RCP 8.5',side=2,las=1,cex=1.25,adj=0.75,padj=-0.9)
mtext('Unweighted',side=2,las=1,cex=1.25,adj=0.8)
mtext('Multimodel Mean',side=2,las=1,cex=1.25,adj=0.7,padj=2)
mtext('(a)',side=3,adj=0,padj=1)
image.plot(legend.only=T,legend.args=list(text=legendlab,cex=1.3,line=0.2),legend.mar=2,zlim=range(mm_map,na.rm=T),col=inferno(100))
for (i in 1:4) {
    par(fig=fig_margins[i,],mar=mar_margins,new=T)
    image(longitude,latitude,comp_mm_array[,,i],xlim=xlimit,ylim=ylimit,axes=F,xlab='',ylab='',zlim=zlimit,col=rev(pal(100)))
    mtext(c('(b)','(c)','(d)','(e)')[i],side=3,adj=0,padj=1)
    if (i <= 2) mtext(paste0(c('BEST','Livneh'),'-weighted')[i],side=2,las=1,cex=1.25,adj=0.45,padj=2.5)
    if (i==1) title('Using Subset Considering \nPerfect Model Test')
    if (i==3) title('Using Subset Considering Only \nMinimum Multimodel RMSE')
    par(fig=fig_margins[i,],new=T); #map('state',add=T)
}

par(fig=c(0,1,0,1),new=T)
image.plot(legend.only=T,legend.args=list(text=expression('Difference from Unweighted Multimodel Mean (K'~century^-1*')'),cex=1.3,side=1,line=3.3),legend.shrink=0.95,legend.mar=4.5,zlim=zlimit,col=rev(pal(100)),horizontal=T)
#title(title,line=2,cex.main=1.5)
if (!(is.null(pdftitle))) dev.off()
stop()

# plot_five_maps Function
########################################################################################
plot_five_maps = function(map_array,title,legendlab=expression(K~century^-1),type='standard',pdftitle=NULL,zlimit=NULL) {
if (is.null(pdftitle)) dev.new(width=12) else
pdf(pdftitle,width=12)

xlimit = c(-126,-66); ylimit = c(24,50)
lim1   = 0.45; lim2 = 0.55
fig_margins     = matrix(NA,5,4)
fig_margins[1,] = c(0,0.4,0.1,0.9); fig_margins[2,] = c(0.33,0.7,lim1,1); fig_margins[3,] = c(0.63,1,lim1,1); fig_margins[4,] = c(0.33,0.7,0,lim2); fig_margins[5,] = c(0.63,1,0,lim2)
mar_margins     = matrix(c(2.1,2,4.1,2.1),5,4,byrow=T)

for (i in 1:5) {
    extreme_map = map_array[,,i]
    if (i == 1) {
       par(fig=fig_margins[i,],mar=mar_margins[i,])
       image.plot(lon,lat,extreme_map,axes=F,xlab='',ylab='',xlim=xlimit,ylim=ylimit,zlim=zlimit,main=season_names[i],line=0.5,cex.main=1.4,legend.args=list(text=legendlab,cex=1.4,side=3,line=0.5),legend.mar=6,axis.args=list(cex.axis=1.4),horizontal=T,col=colors)                   # first 'line' for title purposes
    } else {
       par(fig=fig_margins[i,],mar=mar_margins[i,],new=T)
       image(lon,lat,extreme_map,axes=F,xlab='',ylab='',xlim=xlimit,ylim=ylimit,zlim=zlimit,main=season_names[i],line=0.5,cex.main=1.4,col=colors)   # col=tim.colors(), brewer.pal(n=11,name='RdBu')
    }
    par(fig=fig_margins[i,],new=T); map('state',add=T)
}

par(fig=c(0,1,0,1),new=T)
title(title,line=2,cex.main=1.5)
if (!(is.null(pdftitle))) dev.off()
}
