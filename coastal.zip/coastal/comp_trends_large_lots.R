library(fields)
library(abind)
library(viridis)
library(plotrix)
source('~/box_of_helper_functions.R')
load('pol_mat_LOCA_rcp85.RData')

modelNames = c("ACCESS1-0", "ACCESS1-3", "CCSM4", "CESM1-BGC",
                "CESM1-CAM5", "CMCC-CM", "CMCC-CMS", "CNRM-CM5",
                "CSIRO-Mk3-6-0", "CanESM2", "EC-EARTH", "FGOALS-g2",
                "GFDL-CM3", "GFDL-ESM2G", "GFDL-ESM2M",
                "HadGEM2-AO", "IPSL-CM5A-LR", "IPSL-CM5A-MR",
                "MIROC-ESM", "MIROC-ESM-CHEM", "MIROC5", "MPI-ESM-LR",
                "MPI-ESM-MR", "MRI-CGCM3", "NorESM1-M",
                "bcc-csm1-1", "bcc-csm1-1-m", "inmcm4",
		"GISS-E2-H", "GISS-E2-R", "HadGEM2-CC", "HadGEM2-ES")
n_models = length(modelNames)

load('ACCESS1-0/ACCESS1-0_2006_2099.RData'); longitude = lon; latitude = lat
start_year = 2006; end_year = 2099
max_trend_array  = array(NA,dim=c(length(lon),length(lat),n_models)); div_max_trend_mat  = matrix(NA,n_models,8)
mean_trend_array = array(NA,dim=c(length(lon),length(lat),n_models)); div_mean_trend_mat = matrix(NA,n_models,8)
ptm = proc.time()
for (i in 1:n_models) {
    load(paste0(modelNames[i],'/',modelNames[i],'_',start_year,'_',end_year,'.RData')); trend_max[which(trend_max==-1e99)] = NA
    max_trend_array[,,i]  = trend_max
    mean_trend_array[,,i] = trend_mean
    for (j in 1:7) {
    	inds = which(pol_mat_rcp85 == j,arr.ind=T)
	div_max_trend_mat[i,j]  = mean(trend_max[inds],na.rm=T)
	div_mean_trend_mat[i,j] = mean(trend_mean[inds],na.rm=T)
    }
    div_max_trend_mat[i,8]  = area_weighted_average(longitude,latitude,trend_max)
    div_mean_trend_mat[i,8] = area_weighted_average(longitude,latitude,trend_mean)
}
#save(div_max_trend_mat,div_mean_trend_mat,file='div_rcp85_trends32.RData')
mm_max  = apply(max_trend_array,c(1,2),mean,na.rm=T)
mm_mean = apply(mean_trend_array,c(1,2),mean,na.rm=T)
cat('time to load LOCA RCP 8.5 trends is',proc.time()-ptm,fill=T)

get_subset_ind = function(inside_mat,rmse_vec) {
	       inside_vec = apply(inside_mat,1,min)
	       ind_cands  = which(inside_vec >= 0.8)
	       if (length(ind_cands) == 0) ind_cands = which(inside_vec == max(inside_vec))
	       ind_cands = c(ind_cands,n_models)
	       ind = ind_cands[which(rmse_vec[ind_cands]==min(rmse_vec[ind_cands]))]
return(ind)
}

dataset_inds = c(1,2,4,6,8,10); n_datasets = length(dataset_inds)
datasets     = c('BEST','nclimdiv','livneh_v1_1','livneh_v1_2','AgCFSR','CFSR','AgMERRA','MERRA','MERRA2','ERA5','NOAA_20CRv3','ERA_20C','JRA_55C')[dataset_inds]
starting_yrs = c(1950,1951,NA,1950,1980,1980,1980,1980,1980,1980,1950,1950,1980)[dataset_inds]

start_years = 1950:1985; n_periods = length(start_years)
end_year    = 2005
suffix_list = c('','_var3')[1]
var_str     = c('','_spacetime')[2]

model_master_max = array(0,dim=c(n_periods,n_models,6)); model_master_mean = array(0,dim=c(n_periods,n_models,6))
for (suffix in suffix_list) {
    max_trend_ca_array = array(NA,dim=c(n_periods,8,n_datasets))                                 ; mean_trend_ca_array = array(NA,dim=c(n_periods,8,n_datasets))
    max_ind_mat        = matrix(NA,n_periods,n_datasets)                                         ; mean_ind_mat        = matrix(NA,n_periods,n_datasets)
    rmse_perf_max_mat  = array(NA,dim=c(n_periods,n_datasets,2,2))                               ; rmse_perf_mean_mat  = array(NA,dim=c(n_periods,n_datasets,2,2))
    future_max_trend   = array(NA,dim=c(n_periods,8,n_datasets,3))                               ; future_mean_trend   = array(NA,dim=c(n_periods,8,n_datasets,3))
    comp_mm_max        = array(NA,dim=c(length(longitude),length(latitude),n_periods,n_datasets)); comp_mm_mean        = array(NA,dim=c(length(longitude),length(latitude),n_periods,n_datasets))
    for (i in 1:n_datasets) {
    	ptm = proc.time()
	for (start_year in starting_yrs[i]:max(start_years)) {
	    year_ind = start_year - min(start_years) + 1
	    load(paste0('../LOCA/raw_data/gurobi_large/gurobi_large32',var_str,datasets[i],'_',start_year,'_',end_year,suffix,'.RData'))
#	    max_ind = which(rmse_mat[,1]==min(rmse_mat[,1])); mean_ind = which(rmse_mat[,2]==min(rmse_mat[,2]))
#	    max_ind = 25; mean_ind = 21             # fixed

	    max_ind                            = get_subset_ind(inside_max_mat,rmse_mat[,1]); model_master_max[year_ind,model_list_max[[max_ind]],i] = model_master_max[year_ind,model_list_max[[max_ind]],i] + 1
	    max_ind_mat[year_ind,i]            = max_ind
	    comp_mm_max[,,year_ind,i]          = apply(max_trend_array[,,model_list_max[[max_ind]]],c(1,2),mean,na.rm=T) - mm_max
	    rmse_perf_max_tmp                  = (rmse_perf_max_mm-rmse_perf_max)/rmse_perf_max_mm*100
	    rmse_perf_max_mat[year_ind,i,,1]   = apply(rmse_perf_max_tmp[max_ind,,],1,mean); rmse_perf_max_mat[year_ind,i,,2] = apply(rmse_perf_max_tmp[max_ind,,],1,sd)
	    future_max_trend[year_ind,8,i,1:2] = quantile(div_max_trend_mat[model_list_max[[max_ind]],8],c(0.17,0.83))
	    future_max_trend[year_ind,8,i,3]   = mean(div_max_trend_mat[model_list_max[[max_ind]],8])
#	    future_max_trend[year_ind,8,i,1:2] = future_max_trend[year_ind,8,i,3] + c(-1,1)*sd(div_max_trend_mat[model_list_max[[max_ind]],8])

	    mean_ind                            = get_subset_ind(inside_mean_mat,rmse_mat[,2]); model_master_mean[year_ind,model_list_mean[[mean_ind]],i] = model_master_mean[year_ind,model_list_mean[[mean_ind]],i] + 1
	    mean_ind_mat[year_ind,i]            = mean_ind
	    comp_mm_mean[,,year_ind,i]          = apply(mean_trend_array[,,model_list_mean[[mean_ind]]],c(1,2),mean,na.rm=T) - mm_mean
	    rmse_perf_mean_tmp                  = (rmse_perf_mean_mm-rmse_perf_mean)/rmse_perf_mean_mm*100
	    rmse_perf_mean_mat[year_ind,i,,1]   = apply(rmse_perf_mean_tmp[mean_ind,,],1,mean); rmse_perf_mean_mat[year_ind,i,,2] = apply(rmse_perf_mean_tmp[mean_ind,,],1,sd)
	    future_mean_trend[year_ind,8,i,1:2] = quantile(div_mean_trend_mat[model_list_mean[[mean_ind]],8],c(0.17,0.83))
	    future_mean_trend[year_ind,8,i,3]   = mean(div_mean_trend_mat[model_list_mean[[mean_ind]],8])
#	    future_mean_trend[year_ind,8,i,1:2] = future_mean_trend[year_ind,8,i,3] + c(-1,1)*sd(div_mean_trend_mat[model_list_mean[[mean_ind]],8])

            max_trend_ca_array[year_ind,8,i]  = area_weighted_average(longitude,latitude,comp_mm_max[,,year_ind,i])
            mean_trend_ca_array[year_ind,8,i] = area_weighted_average(longitude,latitude,comp_mm_mean[,,year_ind,i])
            for (j in 1:7) {
                inds = which(pol_mat_rcp85 == j,arr.ind=T)
                max_trend_ca_array[year_ind,j,i]    = mean(comp_mm_max[,,year_ind,i][inds],na.rm=T)
                mean_trend_ca_array[year_ind,j,i]   = mean(comp_mm_mean[,,year_ind,i][inds],na.rm=T)
		future_max_trend[year_ind,j,i,1:2]  = quantile(div_max_trend_mat[model_list_max[[max_ind]],j],c(0.17,0.83))
		future_max_trend[year_ind,j,i,3]    = mean(div_max_trend_mat[model_list_max[[max_ind]],j])
#		future_max_trend[year_ind,j,i,1:2]  = future_max_trend[year_ind,j,i,3] + c(-1,1)*sd(div_max_trend_mat[model_list_max[[max_ind]],j])
		future_mean_trend[year_ind,j,i,1:2] = quantile(div_mean_trend_mat[model_list_mean[[mean_ind]],j],c(0.17,0.83))
		future_mean_trend[year_ind,j,i,3]   = mean(div_mean_trend_mat[model_list_mean[[mean_ind]],j])
#		future_mean_trend[year_ind,j,i,1:2] = future_mean_trend[year_ind,j,i,3] + c(-1,1)*sd(div_mean_trend_mat[model_list_mean[[mean_ind]],j])
            }
	}
	cat('time to do',datasets[i],':',proc.time()-ptm,fill=T); ptm = proc.time()
    }
    filename = paste0('gurobi_comp_trends_large_lots',var_str,suffix,'32.RData')
#    filename = paste0('gurobi_comp_trends_large_lots_rmse',var_str,suffix,'32.RData')
#    save(max_trend_ca_array,mean_trend_ca_array,max_ind_mat,mean_ind_mat,rmse_perf_max_mat,rmse_perf_mean_mat,future_max_trend,future_mean_trend,comp_mm_max,comp_mm_mean,file=filename)
#    filename = paste0('gurobi_comp_trends_large_lots_fixed',suffix,'.RData')
#    save(max_trend_ca_array,mean_trend_ca_array,max_ind_mat,mean_ind_mat,file=filename)
}


#color_list = c('red','orange','green')
#dev.new(width=10); par(mfrow=c(1,2))
#ylimit = range(A,na.rm=T)
#plot(NULL,type='n',xlim=range(start_years),ylim=ylimit,main='Max',xlab='Historical Trend Start Year',ylab='Difference from Unweighted Multimodel Mean (K/century)')
#for (i in 1:3) {
#    lines(start_years,A[,i,1],col=color_list[i],type='o')
#}
#plot(NULL,type='n',xlim=range(start_years),ylim=ylimit,main='Mean',xlab='Historical Trend Start Year',ylab='Difference from Unweighted Multimodel Mean (K/century)')
#for (i in 1:3) {
#    lines(start_years,A[,i,2],col=color_list[i],type='o')
#}
#legend('topright',datasets,lty=rep(1,3),col=color_list)
#mtext('Subset size 16',adj=-0.4,line=2)
