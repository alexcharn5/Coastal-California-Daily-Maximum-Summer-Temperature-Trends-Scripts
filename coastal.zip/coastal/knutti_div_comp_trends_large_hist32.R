library(ncdf4)
library(fields)
library(maps)
library(sp)
library(viridis)
library(scales)
source('~/box_of_helper_functions.R')

start_year   = 1950; end_year = 1985
year_list    = start_year:end_year; n_years    = length(year_list)
dataset_inds = c(1,2,4,6,8,10)    ; n_datasets = length(dataset_inds)

datasets = c('BEST','nclimdiv','livneh_v1_1','livneh_v1_2','AgCFSR','CFSR','AgMERRA','MERRA','MERRA2','ERA5','NOAA_20CRv3','ERA_20C','JRA_55C')[dataset_inds]
#titles   = c('BEST','nclimdiv','LIVNEH v1.1','LIVNEH v1.2','AgCFSR','CFSR','AgMERRA','MERRA','MERRA2','ERA5','NOAA 20CRv3','ERA 20C','JRA-55C')[dataset_inds]
titles   = c('BEST','nClimGrid','LIVNEH v1.1','Livneh','AgCFSR','CFSR','AgMERRA','MERRA','MERRA2','ERA5','NOAA 20CRv3','ERA 20C','JRA-55C')[dataset_inds]
col_list = c('red','orange','green','green','blue','blue','magenta','magenta','magenta','brown','black','black','black','brown1','cyan')[dataset_inds]

modelNames = c("ACCESS1-0", "ACCESS1-3", "CCSM4", "CESM1-BGC",
                "CESM1-CAM5", "CMCC-CM", "CMCC-CMS", "CNRM-CM5",
                "CSIRO-Mk3-6-0", "CanESM2", "EC-EARTH", "FGOALS-g2",
                "GFDL-CM3", "GFDL-ESM2G", "GFDL-ESM2M",
                "HadGEM2-AO", "IPSL-CM5A-LR", "IPSL-CM5A-MR",
                "MIROC-ESM", "MIROC-ESM-CHEM", "MIROC5", "MPI-ESM-LR",
                "MPI-ESM-MR", "MRI-CGCM3", "NorESM1-M",
                "bcc-csm1-1", "bcc-csm1-1-m", "inmcm4",
		"GISS-E2-H", "GISS-E2-R", "HadGEM2-CC", "HadGEM2-ES")
n_models = length(modelNames)

suffix = c('','_var3')[1]
load(paste0('gurobi_comp_trends_large_lots_hist32',suffix,'.RData'))
obs_max_trend_ca_array = obs_max_trend_ca_array*10; obs_mean_trend_ca_array = obs_mean_trend_ca_array*10
max_trend_ca_array     = max_trend_ca_array*10    ; mean_trend_ca_array     = mean_trend_ca_array*10
loca_max_trends        = loca_max_trends*10       ; loca_mean_trends        = loca_mean_trends*10
pdf_title_max  = paste0('gurobi_div_comp_max_hist',suffix,'32.pdf')
pdf_title_mean = paste0('gurobi_div_comp_mean_hist',suffix,'32.pdf')
pdf_title      = paste0('gurobi_comp_hist',suffix,'32.pdf')

pdf(pdf_title,width=10)
par(mfrow=c(1,2))
ylimit = range(c(max_trend_ca_array[,8,],mean_trend_ca_array[,8,],obs_max_trend_ca_array[,8,],obs_mean_trend_ca_array[,8,],loca_max_trends[,8,],loca_mean_trends[,8,]),na.rm=T)
#ylimit = range(c(obs_max_trend_ca_array[,8,],obs_mean_trend_ca_array[,8,]),na.rm=T)
plot(NULL,xlim=range(year_list),ylim=ylimit,xlab='Historical Trend Start Year',ylab='Trend (K/decade)',main='Max')
abline(h=0,lty=3)
for (j in 1:n_datasets) {
    lines(year_list,obs_max_trend_ca_array[,8,j],col=col_list[j])
#    lines(year_list,max_trend_ca_array[,8,j],col=col_list[j],lty=2)
}
lines(year_list,max_trend_ca_array[,8,7],lty=2)
lines(year_list,max_trend_ca_array[,8,8],lty=4); lines(year_list,max_trend_ca_array[,8,9],lty=4)
legend('topleft',c(titles,'LOCA Unweighted Mean'),lty=rep(1,n_datasets+1),col=c(col_list,'black'),cex=0.8)
#legend('topleft',titles,lty=rep(1,n_datasets),col=col_list,cex=0.8)

plot(NULL,xlim=range(year_list),ylim=ylimit,xlab='Historical Trend Start Year',ylab='Trend (K/decade)',main='Mean')
abline(h=0,lty=3)
for (j in 1:n_datasets) {
    lines(year_list,obs_mean_trend_ca_array[,8,j],col=col_list[j])
#    lines(year_list,mean_trend_ca_array[,8,j],col=col_list[j],lty=2)
}
#lines(year_list,obs_mean_trend_ca_array[,8,7],lty=2,col='green')
#lines(year_list,obs_mean_trend_ca_array[,8,8],lty=2,col='red')
lines(year_list,mean_trend_ca_array[,8,7],lty=2)
lines(year_list,mean_trend_ca_array[,8,8],lty=4); lines(year_list,mean_trend_ca_array[,8,9],lty=4)
legend('topleft',c('Observations','LOCA'),lty=c(1,2),cex=0.8)
#legend('topleft',c('Homogenized Stations','Nonhomogenized Stations'),lty=rep(2,2),col=c('red','green'),cex=0.8)
dev.off()


pdf(pdf_title_max,width=10,height=8); layout(matrix(c(1:3,4,5,6,4,7,8),3,3,byrow=TRUE)); par(mar=c())
ylimit = range(c(max_trend_ca_array,obs_max_trend_ca_array,loca_max_trends),na.rm=T)
#ylimit = range(obs_max_trend_ca_array,na.rm=T)
for (i in 1:7) {
    plot(NULL,xlim=range(year_list),ylim=ylimit,xlab='Historical Trend Start Year',ylab='Trend (K/decade)',main=paste0('Climate Division ',i),cex.lab=1.2,cex.axis=1.2)
    abline(h=0,lty=3)
    for (j in 1:n_datasets) {
    	lines(year_list,obs_max_trend_ca_array[,i,j],col=col_list[j],lwd=1.5)
#	lines(year_list,max_trend_ca_array[,i,j],col=col_list[j],lty=2)
    }
    for (j in 1:n_models) {
    	lines(year_list,loca_max_trends[,i,j],col=alpha('black',0.1))
    }
#    lines(year_list,max_trend_ca_array[,i,7],lty=2)
#    lines(year_list,max_trend_ca_array[,i,8],lty=4); lines(year_list,max_trend_ca_array[,i,9],lty=4)
    if (i == 3) {
       plot_climate_divisions()
       title('Map of California Climate Divisions')
#       legend('topright',titles,lty=rep(1,n_datasets),col=col_list,cex=0.8)
#       title('Max Trend (K/decade)')
       legend('topright',c(titles,NA,'LOCA Models'),lty=rep(1,NA,n_datasets+1),col=c(col_list,NA,'gray'),cex=1.1)
    }
}
dev.off()

pdf(pdf_title_mean,width=10,height=8); layout(matrix(c(1:3,4,5,6,4,7,8),3,3,byrow=TRUE)); par(mar=c())
ylimit = range(c(mean_trend_ca_array,obs_mean_trend_ca_array,loca_mean_trends),na.rm=T)
#ylimit = range(obs_mean_trend_ca_array,na.rm=T)
for (i in 1:7) {
    plot(NULL,xlim=range(year_list),ylim=ylimit,xlab='Historical Trend Start Year',ylab='Trend (K/decade)',main=paste0('Climate Division ',i),cex.lab=1.2,cex.axis=1.2)
    abline(h=0,lty=3)
    for (j in 1:n_datasets) {
        lines(year_list,obs_mean_trend_ca_array[,i,j],col=col_list[j],lwd=1.5)
#	lines(year_list,mean_trend_ca_array[,i,j],col=col_list[j],lty=2)
    }
    for (j in 1:n_models) {
    	lines(year_list,loca_mean_trends[,i,j],col=alpha('black',0.1))
    }
#    lines(year_list,obs_mean_trend_ca_array[,i,7],lty=2,col='green')
#    lines(year_list,obs_mean_trend_ca_array[,i,8],lty=2,col='red')
#    lines(year_list,mean_trend_ca_array[,i,7],lty=2)
#    lines(year_list,mean_trend_ca_array[,i,8],lty=4); lines(year_list,mean_trend_ca_array[,i,9],lty=4)
    if (i == 3) {
       plot_climate_divisions()
       title('Map of California Climate Divisions')
#       legend('topright',c(titles,'','Homogenized Stations','Nonhomogenized Stations'),lty=c(rep(1,n_datasets),NA,rep(2,2)),col=c(col_list,NA,'red','green'),cex=0.8)
#       title('Mean Trend (K/decade)')
       legend('topright',c(titles,NA,'LOCA Models'),lty=rep(1,NA,n_datasets+1),col=c(col_list,NA,'gray'),cex=1.1)
    }
}
dev.off()
