library(ncdf4)
library(fields)
library(maps)
library(abind)
library(climextRemes)
library(ismev)
source('~/box_of_helper_functions.R')

start_year = 1950; end_year = 2005
bound      = 1/100                   # 1 deg/century

dataset       = 'BEST'
output_prefix = paste0(dataset,'_',start_year,'_',end_year)

tmax1_max      = NULL; tmax1_avg = NULL
file_inds      = seq(1880,2010,10)
relevant_files = which(file_inds>(start_year-10) & file_inds<=end_year)
file_inds      = file_inds[relevant_files]; print(file_inds)
for (i in 1:length(file_inds)) {
    ptm      = proc.time()
    file_ind = file_inds[i]
    nc       = nc_open(paste0('Complete_TMAX_Daily_LatLong1_',file_ind,'.nc'))
    year     = ncvar_get(nc,'year')
    month    = ncvar_get(nc,'month')
    if (i == 1) {
       lon        = ncvar_get(nc,'longitude'); lat = ncvar_get(nc,'latitude')
       lonlat_mat = as.matrix(expand.grid(lon,lat))
       geog       = matrix(map.where('state',lonlat_mat[,1],lonlat_mat[,2]),length(lon),length(lat))
       in_ca      = which(geog=='california',arr.ind=T)
       lon_bounds = range(in_ca[,1]); lat_bounds = range(in_ca[,2]); cat('lon_bounds:',lon_bounds,'& lat_bounds:',lat_bounds,fill=T)
       lon        = lon[lon_bounds[1]:lon_bounds[2]]; lat = lat[lat_bounds[1]:lat_bounds[2]]
    }
    
    if (start_year >= file_ind) start_ind = start_year else
    start_ind = file_ind
    if (file_ind == max(file_inds)) end_ind = end_year else
    end_ind = file_ind + 9
    year_list = start_ind:end_ind; print(range(year_list))
    
    for (year_ind in year_list) {
    	jja_inds  = which(year==year_ind & month%in%6:8)
	tmax1_tmp = ncvar_get(nc,'temperature',start=c(lon_bounds[1],lat_bounds[1],jja_inds[1]),count=c(length(lon),length(lat),length(jja_inds))) + ncvar_get(nc,'climatology',start=c(lon_bounds[1],lat_bounds[1],31+28+31+30+31+1),count=c(length(lon),length(lat),92))
	if (year_ind == year_list[1]) print(dim(tmax1_tmp))
	tmax1_max = abind(tmax1_max,array(apply(tmax1_tmp,c(1,2),max,na.rm=T),dim=c(length(lon),length(lat),1)))
	tmax1_avg = abind(tmax1_avg,array(apply(tmax1_tmp,c(1,2),mean,na.rm=T),dim=c(length(lon),length(lat),1)))
    }
    cat('dim(tmax1_max) = ',dim(tmax1_max),fill=T)
    cat('time to do ',file_ind,'s is',proc.time()-ptm,fill=T)
}
if (all(diff(lat) < 0)) {
   lat = rev(lat); tmax1_max = tmax1_max[,length(lat):1,]; tmax1_avg = tmax1_avg[,length(lat):1,]
}
save(tmax1_max,tmax1_avg,lon,lat,file=paste0('intermediate_data/',output_prefix,'_intermediate_data.RData'))
#load(paste0(output_prefix,'_intermediate_data.RData'))
lonlat_mat   = as.matrix(expand.grid(lon,lat))
geog         = matrix(map.where('state',lonlat_mat[,1],lonlat_mat[,2]),length(lon),length(lat))
in_ca_finite = which(geog=='california' & is.finite(apply(tmax1_max,c(1,2),max)),arr.ind=T); print(dim(in_ca_finite))
trend_max    = matrix(NA,length(lon),length(lat)); trend_mean = trend_max; percent = 0
year_list    = start_year:end_year
z_sc_max     = matrix(NA,length(lon),length(lat)); z_sc_mean  = z_sc_max
p_val_max    = matrix(NA,length(lon),length(lat)); p_val_mean = p_val_max
p_val_zero   = array(NA,dim=c(length(lon),length(lat),2))
for (i in 1:dim(in_ca_finite)[1]) {
    if (i/dim(in_ca_finite)[1]*100 > percent) {cat(percent,'% done',fill=T); percent = percent + 5}
    lon_ind = in_ca_finite[i,1]; lat_ind = in_ca_finite[i,2]

    y    = tmax1_max[lon_ind,lat_ind,]
    vals = compare_gev(year_list,y,indices=1)
    if (is.finite(vals[2])) {
       trend_max[lon_ind,lat_ind] = vals[1]
       p_val_max[lon_ind,lat_ind] = vals[2]
       z_sc_max[lon_ind,lat_ind]  = vals[3]
    } else {
       trend_max[lon_ind,lat_ind] = -1e99
    }
#    fit0 = fit_gev(y,getParams=T,optimArgs=list(control=list(maxit=1e5)),initial=list(location=mean(y),scale=sd(y),shape=0))
#    fit1 = fit_gev(y,x=data.frame(years=year_list),locationFun=~years,getParams=T,optimArgs=list(control=list(maxit=1e5)),initial=list(location=c(fit0$mle[1],0),scale=fit0$mle[2],shape=fit0$mle[3]))
#    if (!(fit1$info$failure)) {
#       trend_max[lon_ind,lat_ind] = fit1$mle[2]
#       z_sc_max[lon_ind,lat_ind]  = fit1$mle[2]/fit1$se_mle[2]
#       if (!(fit0$info$failure)) {
#       	  z                          = 2*(fit0$nllh-fit1$nllh)
#	  p_val_max[lon_ind,lat_ind] = pchisq(z,df=1,lower.tail=F)
#       } else {
#       	  print('weird')
#       }
#    } else {
#       trend_max[lon_ind,lat_ind] = -1e99
#    }

    fit2 = lm(as.numeric(tmax1_avg[lon_ind,lat_ind,])~as.numeric(year_list)); if (fit2$df!=(length(year_list)-2)) print(c(fit2$df,length(year_list)-2))
    trend_mean[lon_ind,lat_ind] = as.numeric(fit2$coefficients[2])
    z_sc_mean[lon_ind,lat_ind]  = summary(fit2)$coefficients[2,1]/summary(fit2)$coefficients[2,2]
    p_val_mean[lon_ind,lat_ind] = summary(fit2)$coefficients[2,4]

    stn_error                     = summary(fit2)$coefficients[2,2]
    p_val_zero[lon_ind,lat_ind,1] = pt((trend_mean[lon_ind,lat_ind]--bound)/stn_error,df=fit2$df,lower.tail=F)
    p_val_zero[lon_ind,lat_ind,2] = pt((bound-trend_mean[lon_ind,lat_ind])/stn_error,df=fit2$df,lower.tail=F)
}
save(trend_max,trend_mean,z_sc_max,z_sc_mean,p_val_max,p_val_mean,lon,lat,p_val_zero,file=paste0(output_prefix,'.RData'))
