library(ncdf4)
library(fields)
library(maps)
library(abind)
library(climextRemes)
library(ismev)
library(akima)
library(RColorBrewer)
source('~/box_of_helper_functions.R')
load('BEST_coords.RData')
lon_best   = lon; lat_best = lat
lonlat_mat = as.matrix(expand.grid(lon_best,lat_best))
geog_best  = matrix(map.where('state',lonlat_mat[,1],lonlat_mat[,2]),length(lon_best),length(lat_best))
in_ca_best = which(geog_best=='california',arr.ind=T)

start_year = 1981; end_year = 2005
bound      = 1/100                   # 1 deg/century

dataset       = 'ERA5'
output_prefix = paste0(dataset,'_large_',start_year,'_',end_year)

tmax1_max = NULL; tmax1_avg = NULL
year_list = start_year:end_year
for (year in year_list) {
    ptm       = proc.time()
    tmax1_tmp = NULL
    for (month in 6:8) {
    	if (month == 6) ndays = 30 else
	ndays = 31
    	filename = paste0('/global/cfs/cdirs/m3522/cmip6/ERA5/e5.oper.an.sfc/',year,0,month,'/e5.oper.an.sfc.128_167_2t.ll025sc.',year,0,month,'0100_',year,0,month,ndays,'23.nc')
    	nc       = nc_open(filename)
	if (year==year_list[1] & month==6) {
	   lon                 = ncvar_get(nc,'longitude'); lat = ncvar_get(nc,'latitude')
	   lon[which(lon>180)] = lon[which(lon>180)] - 360
	   lonlat_mat          = as.matrix(expand.grid(lon,lat))
	   geog                = matrix(map.where('state',lonlat_mat[,1],lonlat_mat[,2]),length(lon),length(lat))
	   in_ca               = which(geog=='california',arr.ind=T)
	   lon_bounds          = range(in_ca[,1]); lat_bounds = range(in_ca[,2]); cat('lon_bounds:',lon_bounds,'& lat_bounds:',lat_bounds,fill=T)
	   lon                 = lon[lon_bounds[1]:lon_bounds[2]]; lat = lat[lat_bounds[1]:lat_bounds[2]]
	}
	t_tmp   = ncvar_get(nc,'VAR_2T',start=c(lon_bounds[1],lat_bounds[1],1),count=c(length(lon),length(lat),-1)); if (year==year_list[1] & month==6) print(dim(t_tmp))
	cur_ind = 1
	while (cur_ind < dim(t_tmp)[3]) {
	      tmax1_tmp = abind(tmax1_tmp,array(apply(t_tmp[,,cur_ind:(cur_ind+23)],c(1,2),max,na.rm=T),dim=c(length(lon),length(lat),1)))
	      cur_ind   = cur_ind + 24
	}
	if (year == year_list[1]) print(dim(tmax1_tmp))
    }
    tmax1_max_tmp = apply(tmax1_tmp,c(1,2),max,na.rm=T) ; tmax1_max_best_tmp = matrix(NA,length(lon_best),length(lat_best)); finite_max  = which(is.finite(tmax1_max_tmp),arr.ind=T)
    tmax1_avg_tmp = apply(tmax1_tmp,c(1,2),mean,na.rm=T); tmax1_avg_best_tmp = matrix(NA,length(lon_best),length(lat_best)); finite_mean = which(is.finite(tmax1_avg_tmp),arr.ind=T)
    tmax1_max_best_tmp[in_ca_best] = interpp(lon[finite_max[,1]],lat[finite_max[,2]],tmax1_max_tmp[finite_max],lon_best[in_ca_best[,1]],lat_best[in_ca_best[,2]])$z
    tmax1_avg_best_tmp[in_ca_best] = interpp(lon[finite_mean[,1]],lat[finite_mean[,2]],tmax1_avg_tmp[finite_mean],lon_best[in_ca_best[,1]],lat_best[in_ca_best[,2]])$z
    tmax1_max = abind(tmax1_max,tmax1_max_best_tmp,along=3)
    tmax1_avg = abind(tmax1_avg,tmax1_avg_best_tmp,along=3)
    cat('dim(tmax1_max) = ',dim(tmax1_max),fill=T)
    cat('time to do ',year,'is',proc.time()-ptm,fill=T)
}
lon = lon_best; lat = lat_best
if (all(diff(lat) < 0)) {
   lat = rev(lat); tmax1_max = tmax1_max[,length(lat):1,]; tmax1_avg = tmax1_avg[,length(lat):1,]
}
save(tmax1_max,tmax1_avg,lon,lat,file=paste0('intermediate_data/',output_prefix,'_intermediate_data.RData'))
#load(paste0(output_prefix,'_intermediate_data.RData'))
lonlat_mat   = as.matrix(expand.grid(lon,lat))
geog         = matrix(map.where('state',lonlat_mat[,1],lonlat_mat[,2]),length(lon),length(lat))
in_ca_finite = which(geog=='california' & is.finite(apply(tmax1_max,c(1,2),max)),arr.ind=T); print(dim(in_ca_finite))
trend_max    = matrix(NA,length(lon),length(lat)); trend_mean = trend_max; percent = 0
z_sc_max     = matrix(NA,length(lon),length(lat)); z_sc_mean  = z_sc_max
p_val_max    = matrix(NA,length(lon),length(lat)); p_val_mean = p_val_max
p_val_zero   = array(NA,dim=c(length(lon),length(lat),2))
for (i in 1:dim(in_ca_finite)[1]) {
    if (i/dim(in_ca_finite)[1]*100 > percent) {cat(percent,'% done',fill=T); percent = percent + 5}
    lon_ind = in_ca_finite[i,1]; lat_ind = in_ca_finite[i,2]

    y    = tmax1_max[lon_ind,lat_ind,]
    vals = compare_gev(year_list,y,indices=1)
    if (is.finite(vals[2])) {
       trend_max[lon_ind,lat_ind] = vals[1]
       p_val_max[lon_ind,lat_ind] = vals[2]
       z_sc_max[lon_ind,lat_ind]  = vals[3]
    } else {
       trend_max[lon_ind,lat_ind] = -1e99
    }    
#    fit0 = fit_gev(y,getParams=T,optimArgs=list(control=list(maxit=1e5)),initial=list(location=mean(y),scale=sd(y),shape=0))
#    fit1 = fit_gev(y,x=data.frame(years=year_list),locationFun=~years,getParams=T,optimArgs=list(control=list(maxit=1e5)),initial=list(location=c(fit0$mle[1],0),scale=fit0$mle[2],shape=fit0$mle[3]))
#    if (!(fit1$info$failure)) {
#       trend_max[lon_ind,lat_ind] = fit1$mle[2]
#       z_sc_max[lon_ind,lat_ind]  = fit1$mle[2]/fit1$se_mle[2]
#       if (!(fit0$info$failure)) {
#          z                          = 2*(fit0$nllh-fit1$nllh)
#          p_val_max[lon_ind,lat_ind] = pchisq(z,df=1,lower.tail=F)
#       } else {
#          print('weird')
#       }
#    } else {
#       trend_max[lon_ind,lat_ind] = -1e99
#    }

    fit2 = lm(as.numeric(tmax1_avg[lon_ind,lat_ind,])~as.numeric(year_list)); if (fit2$df!=(length(year_list)-2)) print(c(fit2$df,length(year_list)-2))
    trend_mean[lon_ind,lat_ind] = as.numeric(fit2$coefficients[2])
    z_sc_mean[lon_ind,lat_ind]  = summary(fit2)$coefficients[2,1]/summary(fit2)$coefficients[2,2]
    p_val_mean[lon_ind,lat_ind] = summary(fit2)$coefficients[2,4]

    stn_error                     = summary(fit2)$coefficients[2,2]
    p_val_zero[lon_ind,lat_ind,1] = pt((trend_mean[lon_ind,lat_ind]--bound)/stn_error,df=fit2$df,lower.tail=F)
    p_val_zero[lon_ind,lat_ind,2] = pt((bound-trend_mean[lon_ind,lat_ind])/stn_error,df=fit2$df,lower.tail=F)
}
save(trend_max,trend_mean,z_sc_max,z_sc_mean,p_val_max,p_val_mean,lon,lat,p_val_zero,file=paste0(output_prefix,'.RData'))